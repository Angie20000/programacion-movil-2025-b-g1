import React from "react";

interface LayoutProps {
  children: React.ReactNode;
}

export const Layout: React.FC<LayoutProps> = ({ children }) => {
  return (
    <div style={styles.deviceWrapper}>
  <div style={styles.deviceScreen}>
    {/* Onda superior */}
    <div style={styles.waveTop}>
      <svg viewBox="0 0 375 100" preserveAspectRatio="none" style={styles.svgWave}>
        <path
          d="M0,100 C100,0 275,0 375,100 L375,0 L0,0 Z"
          style={{ fill: "#a6d8ff" }}
        />
      </svg>
    </div>

    <main style={styles.content}>{children}</main>

    {/* Onda inferior */}
    <div style={styles.waveBottom}>
      <svg viewBox="0 0 375 100" preserveAspectRatio="none" style={styles.svgWave}>
        <path
          d="M0,0 C100,100 275,100 375,0 L375,100 L0,100 Z"
          style={{ fill: "#a6d8ff" }}
        />
      </svg>
    </div>
  </div>
</div>

  );
};

const styles = {
  deviceWrapper: {
    width: 375,
    height: 667,
    margin: "20px auto",
    border: "16px black solid",
    borderRadius: 40,
    backgroundColor: "white",
    boxShadow: "0 0 10px rgba(0,0,0,0.3)",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
  },
  deviceScreen: {
    position: "relative" as "relative",
    width: 343,
    height: 635,
    background: "#fff",
    overflow: "hidden",
    borderRadius: 24,
    display: "flex",
    flexDirection: "column" as "column",
    justifyContent: "space-between",
    alignItems: "center",
  },
  waveTop: {
  position: "absolute" as "absolute",
  top: 0,
  left: 0,
  width: "100%",
  height: 100,
  overflow: "hidden",
  zIndex: 0,
},
waveBottom: {
  position: "absolute" as "absolute",
  bottom: 0,
  left: 0,
  width: "100%",
  height: 100,
  overflow: "hidden",
  zIndex: 0,
},
svgWave: {
  width: "100%",
  height: "100%",
},

  content: {
    flexGrow: 1,
    width: "80%",
    marginTop: 120,
    marginBottom: 120,
    zIndex: 1,
  },
};
