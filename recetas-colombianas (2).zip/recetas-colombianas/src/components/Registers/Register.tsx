import { Link } from "react-router-dom";
import "./Register.css";

export default function Register() {
  return (
    <div className="register-page">
      {/* Fondo azul superior */}
      <div className="wave-top"></div>

      {/* Cuadro blanco */}
      <div className="register-card">
        <h2 className="register-title">Registro</h2>

        <form className="register-form">
          <input
            type="text"
            placeholder="Nombre y apellidos"
            className="register-input"
          />
          <input
            type="tel"
            placeholder="Telefono"
            className="register-input"
          />
          <input
            type="email"
            placeholder="Correo"
            className="register-input"
          />
          <input
            type="password"
            placeholder="Contraseña"
            className="register-input"
          />

          <button type="submit" className="register-btn">
            Registrar
          </button>
        </form>

        {/* Flecha volver */}
        <div className="register-back">
          <Link to="/">←</Link>
        </div>
      </div>

      {/* Fondo azul inferior */}
      <div className="wave-bottom"></div>
    </div>
  );
}
