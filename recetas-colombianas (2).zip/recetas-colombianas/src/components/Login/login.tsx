import React, { useState } from 'react';
import './login.css';

const Login: React.FC = () => {
  const [showPassword, setShowPassword] = useState(false);

  return (
    <div className="login-page">
      <div className="wave-top"></div>
      <div className="wave-bottom"></div>

      <div className="login-container">
        <h2>Iniciar sesión</h2>

        <button className="google-btn">
          <img
            src="https://www.svgrepo.com/show/475656/google-color.svg"
            alt="Google"
          />
          <span>Continue with Google</span>
        </button>

        <div className="divider">
          <hr /> <span>o</span> <hr />
        </div>

        <div className="input-group">
          <input type="text" placeholder="Email o teléfono" />
        </div>

        <div className="input-group password-group">
          <input
            type={showPassword ? 'text' : 'password'}
            placeholder="Contraseña"
          />
          <span
            className="toggle-password"
            onClick={() => setShowPassword(!showPassword)}
          >
            {showPassword ? 'Ocultar' : 'Mostrar'}
          </span>
        </div>

        <button className="login-btn">Iniciar sesión</button>

        <p className="register-text">
          ¿No tienes cuenta? <a href="#">Regístrate</a>
        </p>
      </div>
    </div>
  );
};

export default Login;
