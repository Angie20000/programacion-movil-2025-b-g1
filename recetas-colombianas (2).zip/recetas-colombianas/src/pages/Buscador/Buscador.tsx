import React from "react";
import {
  IonPage,
  IonHeader,
  IonContent,
  IonInput,
  IonIcon,
  IonMenuButton,
  IonToolbar,
  IonButtons,
  IonMenu,
  IonList,
  IonItem,
  IonLabel,
  IonTitle,
  IonMenuToggle,
} from "@ionic/react";
import {
  searchOutline,
  heartOutline,
  listOutline,
  chatbubbleOutline,
} from "ionicons/icons";
import "./Buscador.css";

const Buscador: React.FC = () => {
  return (
    <>
      {/* 🔹 Menú lateral personalizado */}
      <IonMenu side="start" contentId="main-content" className="custom-menu">
        <IonHeader className="menu-header">
          <IonToolbar color="transparent">
            <IonTitle className="menu-title">Menú</IonTitle>
          </IonToolbar>
        </IonHeader>

        <IonContent className="menu-content">
          <IonList className="menu-list">
            <IonMenuToggle auto-hide="true">
              <IonItem button routerLink="/favoritos" className="menu-item" detail={false}>
                <IonIcon icon={heartOutline} slot="start" className="menu-icon" />
                <IonLabel>Favoritos</IonLabel>
              </IonItem>

              <IonItem button routerLink="/categorias" className="menu-item" detail={false}>
                <IonIcon icon={listOutline} slot="start" className="menu-icon" />
                <IonLabel>Categorías</IonLabel>
              </IonItem>

              <IonItem button routerLink="/foros" className="menu-item" detail={false}>
                <IonIcon icon={chatbubbleOutline} slot="start" className="menu-icon" />
                <IonLabel>Foros</IonLabel>
              </IonItem>
            </IonMenuToggle>
          </IonList>
        </IonContent>
      </IonMenu>

      {/* 🔹 Contenido principal */}
      <IonPage id="main-content">
        <IonHeader className="buscador-header">
          <div className="wave-top"></div>

          <IonToolbar className="buscador-toolbar" color="transparent">
            <IonButtons slot="start">
              <IonMenuButton className="menu-icon-btn" />
            </IonButtons>

            <div className="logo-container">
              <img src="/logo.png" alt="Arepa" className="logo-img" />
            </div>
          </IonToolbar>
        </IonHeader>

        <IonContent fullscreen className="buscador-content">
          <div className="search-container">
            <IonIcon icon={searchOutline} className="search-icon" />
            <IonInput
              placeholder="Buscas la ciudad"
              className="search-input"
              clearInput
            />
          </div>

          <div className="wave-bottom"></div>
        </IonContent>
      </IonPage>
    </>
  );
};

export default Buscador;
