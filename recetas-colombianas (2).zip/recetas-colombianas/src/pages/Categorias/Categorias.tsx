import React from "react";
import { IonPage, IonContent, IonIcon } from "@ionic/react";
import {
  chevronBackOutline,
  fastFoodOutline,
  restaurantOutline,
  wineOutline,
  iceCreamOutline,
} from "ionicons/icons";
import { useHistory } from "react-router-dom";
import "./Categorias.css";

const Categorias: React.FC = () => {
  const history = useHistory();

  return (
    <IonPage>
      <IonContent fullscreen>
        {/* Curva superior */}
        <div className="curva-superior"></div>

        {/* Botón para volver */}
        <div className="volver-btn" onClick={() => history.push("/")}>
          <IonIcon icon={chevronBackOutline} />
        </div>

        {/* Logo */}
        <div className="logo-container">
          <img src="/logo.png" alt="Logo" className="logo-cat" />
        </div>

        {/* Título */}
        <h1 className="titulo-cat">Categorías</h1>

        {/* Lista de categorías */}
        <div className="lista-categorias">
          <button>
            <IonIcon icon={fastFoodOutline} /> Desayunos
          </button>
          <button>
            <IonIcon icon={restaurantOutline} /> Almuerzos
          </button>
          <button>
            <IonIcon icon={wineOutline} /> Cenas
          </button>
          <button>
            <IonIcon icon={iceCreamOutline} /> Postres
          </button>
        </div>

        {/* Curva inferior */}
        <div className="curva-inferior"></div>
      </IonContent>
    </IonPage>
  );
};

export default Categorias;
