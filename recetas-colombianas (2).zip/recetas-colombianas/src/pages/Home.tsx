import React from "react";
import { IonContent, IonPage, IonButton } from "@ionic/react";
import "./Home.css";



const Home: React.FC = () => {
  const handleLogin = () => {
    // Aquí puedes redirigir al login con React Router
    window.location.href = "/login";
  };

  return (
    <IonPage>
      <IonContent fullscreen className="home-content">
        <div className="wave-top"></div>

        <div className="home-container">
          <img
            src="/logo.png"
            className="home-logo"
          />
          <IonButton expand="block" className="login-button" onClick={handleLogin}>
            Iniciar sesión
          </IonButton>
        </div>

        <div className="wave-bottom"></div>
      </IonContent>
    </IonPage>
  );
};

export default Home;

