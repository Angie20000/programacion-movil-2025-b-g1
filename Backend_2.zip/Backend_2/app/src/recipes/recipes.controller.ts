import { 
  Controller, 
  Get, 
  Post, 
  Delete, 
  Body, 
  Param, 
  Query, 
  UseGuards,
  ParseIntPipe,
  DefaultValuePipe 
} from '@nestjs/common';
import { RecipesService } from './recipes.service';
import { JwtAuthGuard } from '../auth/ jwt-auth.guard';
import { CurrentUser } from '../users/current-user.decorator';

@Controller('recipes')
export class RecipesController {
  constructor(private readonly recipesService: RecipesService) {}

  // ==============================
  // CREAR RECETA (HU-03)
  // ==============================
  @UseGuards(JwtAuthGuard)
  @Post()
  async createRecipe(
    @CurrentUser() user: any,
    @Body() body: {
      title: string;
      description?: string;
      ingredients: string;
      steps: string;
      image_url?: string;
      prep_time?: number;
      cook_time?: number;
      servings?: number;
      difficulty?: string;
      category?: string;
      city?: string;
      tags?: string[];
    },
  ) {
    return this.recipesService.createRecipe(user.user_id, body);
  }

  // ==============================
  // OBTENER TODAS LAS RECETAS (HU-05)
  // ==============================
  @Get()
  async getAllRecipes(
    @Query('page', new DefaultValuePipe(1), ParseIntPipe) page: number,
    @Query('limit', new DefaultValuePipe(10), ParseIntPipe) limit: number,
  ) {
    return this.recipesService.getAllRecipes(page, limit);
  }

  // ==============================
  // BUSCAR RECETAS (HU-06)
  // ==============================
  @Get('search')
  async searchRecipes(
    @Query('q') query: string,
    @Query('city') city?: string,
    @Query('category') category?: string,
  ) {
    if (!query) {
      return { recipes: [], message: 'Ingresa un término de búsqueda' };
    }

    return this.recipesService.searchRecipes(query, city, category);
  }

  // ==============================
  // OBTENER DETALLE DE RECETA (HU-05)
  // ==============================
  @Get(':id')
  async getRecipe(@Param('id') id: string) {
    return this.recipesService.getRecipeById(id);
  }

  // ==============================
  // ELIMINAR RECETA (HU-04)
  // ==============================
  @UseGuards(JwtAuthGuard)
  @Delete(':id')
  async deleteRecipe(
    @CurrentUser() user: any,
    @Param('id') id: string,
  ) {
    return this.recipesService.deleteRecipe(user.user_id, id);
  }

  // ==============================
  // CALIFICAR RECETA (HU-08)
  // ==============================
  @UseGuards(JwtAuthGuard)
  @Post(':id/rate')
  async rateRecipe(
    @CurrentUser() user: any,
    @Param('id') id: string,
    @Body() body: { score: number },
  ) {
    return this.recipesService.rateRecipe(user.user_id, id, body.score);
  }

  // ==============================
  // OBTENER MIS RECETAS
  // ==============================
  @UseGuards(JwtAuthGuard)
  @Get('my/recipes')
  async getMyRecipes(@CurrentUser() user: any) {
    return this.recipesService.getUserRecipes(user.user_id);
  }
}