import { Injectable, NotFoundException, ForbiddenException } from '@nestjs/common';
import { PrismaService } from '../prisma/ prisma.service';

@Injectable()
export class RecipesService {
  constructor(private prisma: PrismaService) {}

  // HU3: Publicar receta
  async createRecipe(userId: string, data: {
    title: string;
    ingredients: string;
    steps: string;
    city: string;
    prep_time?: number;
    cook_time?: number;
    difficulty?: string;
    description?: string;
    image_url?: string;
    category?: string;
    tags?: string[];
  }) {
    // Validar campos obligatorios según HU3
    if (!data.title || !data.ingredients || !data.steps || !data.city) {
      throw new Error('Faltan campos obligatorios: título, ingredientes, pasos o ciudad');
    }

    return this.prisma.recipe.create({
      data: {
        title: data.title,
        ingredients: data.ingredients,
        steps: data.steps,
        city: data.city,
        prep_time: data.prep_time,
        cook_time: data.cook_time,
        difficulty: data.difficulty,
        description: data.description,
        image_url: data.image_url,
        category: data.category,
        tags: data.tags || [],
        author_id: userId,
      },
      include: {
        author: {
          select: {
            id: true,
            name: true,
            username: true,
          },
        },
      },
    });
  }

  // HU5: Listado público con paginación
  async getAllRecipes(limit: number = 10, page: number = 1, city?: string) {
    const skip = (page - 1) * limit;
    
    const where = { 
      is_published: true,
      ...(city && { city: { contains: city, mode: 'insensitive' } })
    };

    const [recipes, total] = await Promise.all([
      this.prisma.recipe.findMany({
        skip,
        take: limit,
        where,
        include: {
          author: {
            select: {
              id: true,
              name: true,
              username: true,
              profile_picture_url: true,
            },
          },
          ratings: {
            select: {
              score: true,
            },
          },
        },
        orderBy: { created_at: 'desc' },
      }),
      this.prisma.recipe.count({ where }),
    ]);

    // Calcular promedio de rating para cada receta
    const recipesWithAvg = recipes.map(recipe => ({
      ...recipe,
      average_rating: recipe.ratings.length > 0 
        ? recipe.ratings.reduce((sum, r) => sum + r.score, 0) / recipe.ratings.length 
        : 0,
      rating_count: recipe.ratings.length,
    }));

    return {
      recipes: recipesWithAvg,
      total,
      page,
      totalPages: Math.ceil(total / limit),
      hasNext: page < Math.ceil(total / limit),
      hasPrev: page > 1,
    };
  }

  // HU6: Buscar por ciudad
  async searchRecipesByCity(city: string) {
    const recipes = await this.prisma.recipe.findMany({
      where: { 
        city: { contains: city, mode: 'insensitive' },
        is_published: true 
      },
      include: {
        author: {
          select: {
            id: true,
            name: true,
            username: true,
          },
        },
        ratings: {
          select: {
            score: true,
          },
        },
      },
      orderBy: { created_at: 'desc' },
    });

    return recipes.map(recipe => ({
      ...recipe,
      average_rating: recipe.ratings.length > 0 
        ? recipe.ratings.reduce((sum, r) => sum + r.score, 0) / recipe.ratings.length 
        : 0,
    }));
  }

  // HU9: Ver detalle de receta
  async getRecipeById(id: string) {
    const recipe = await this.prisma.recipe.findUnique({
      where: { id },
      include: {
        author: {
          select: {
            id: true,
            name: true,
            username: true,
            profile_picture_url: true,
          },
        },
        ratings: {
          include: {
            user: {
              select: {
                name: true,
                username: true,
              },
            },
          },
        },
      },
    });

    if (!recipe) {
      throw new NotFoundException('Receta no encontrada');
    }

    // Calcular promedio
    const average_rating = recipe.ratings.length > 0 
      ? recipe.ratings.reduce((sum, r) => sum + r.score, 0) / recipe.ratings.length 
      : 0;

    return {
      ...recipe,
      average_rating,
      rating_count: recipe.ratings.length,
    };
  }

  // HU4: Eliminar receta (solo autor)
  async deleteRecipe(userId: string, recipeId: string) {
    const recipe = await this.prisma.recipe.findUnique({
      where: { id: recipeId },
    });

    if (!recipe) {
      throw new NotFoundException('Receta no encontrada');
    }

    if (recipe.author_id !== userId) {
      throw new ForbiddenException('No puedes eliminar recetas de otros usuarios');
    }

    // Eliminar en cascada: ratings y favorites asociados
    return this.prisma.$transaction([
      this.prisma.rating.deleteMany({ where: { recipe_id: recipeId } }),
      this.prisma.favorite.deleteMany({ where: { recipe_id: recipeId } }),
      this.prisma.recipe.delete({ where: { id: recipeId } }),
    ]);
  }

  // Obtener recetas de un usuario
  async getUserRecipes(userId: string) {
    return this.prisma.recipe.findMany({
      where: { author_id: userId },
      include: {
        ratings: {
          select: {
            score: true,
          },
        },
      },
      orderBy: { created_at: 'desc' },
    });
  }
}