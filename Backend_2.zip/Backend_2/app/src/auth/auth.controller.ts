import { Body, Controller, Post, UnauthorizedException } from '@nestjs/common';
import { AuthService } from './auth.service';
import { UsersService } from '../users/users.service';

@Controller('auth')
export class AuthController {
  constructor(
    private readonly authService: AuthService,
    private readonly usersService: UsersService,
  ) {}

  @Post('register')
  async register(
    @Body() body: { email: string; password: string; name?: string; username?: string },
  ) {
    return this.usersService.createUser({
      email: body.email,
      password: body.password,
      name: body.name,
      username: body.username,
    });
  }

  @Post('login')
  async login(@Body() body: { email: string; password: string }) {
    const user = await this.usersService.findByEmail(body.email);
    if (!user) throw new UnauthorizedException('Usuario no encontrado');

    const token = await this.authService.validateUser(body.email, body.password);
    return token;
  }
}