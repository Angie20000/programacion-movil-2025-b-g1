import { Module } from '@nestjs/common';
import { AuthModule } from './auth/ auth.module';
import { UsersModule } from './users/users.module';
import { PrismaModule } from './prisma/prisma.module';
import { RecipesModule } from './recipes/recipes.module';
import { FavoritesModule } from './favorites/favorites.module';
import { RatingsModule } from './ratings/ratings.module';

@Module({
  imports: [
    PrismaModule,
    UsersModule, 
    AuthModule,
    RecipesModule,
    FavoritesModule,
    RatingsModule
  ],
  controllers: [],
  providers: [],
})
export class AppModule {}