import { Controller, Get, Post, Body, Param, UseGuards } from '@nestjs/common';
import { RatingsService } from './ratings.service';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { CurrentUser } from '../users/current-user.decorator';

@Controller('ratings')
export class RatingsController {
  constructor(private readonly ratingsService: RatingsService) {}

  // HU8: Calificar receta
  @UseGuards(JwtAuthGuard)
  @Post()
  async rateRecipe(
    @CurrentUser() user: any,
    @Body() body: { recipeId: string; score: number; comment?: string },
  ) {
    return this.ratingsService.rateRecipe(user.user_id, body.recipeId, body.score, body.comment);
  }

  // Obtener ratings de una receta
  @Get('recipe/:recipeId')
  async getRecipeRatings(@Param('recipeId') recipeId: string) {
    return this.ratingsService.getRecipeRatings(recipeId);
  }

  // Obtener mi rating para una receta
  @UseGuards(JwtAuthGuard)
  @Get('recipe/:recipeId/my-rating')
  async getMyRating(
    @CurrentUser() user: any,
    @Param('recipeId') recipeId: string,
  ) {
    return this.ratingsService.getUserRating(user.user_id, recipeId);
  }
}