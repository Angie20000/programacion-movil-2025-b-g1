import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/ prisma.service';

@Injectable()
export class RatingsService {
  constructor(private prisma: PrismaService) {}

  // HU8: Calificar receta
  async rateRecipe(userId: string, recipeId: string, score: number, comment?: string) {
    // Validar score
    if (score < 1 || score > 5) {
      throw new Error('La calificación debe estar entre 1 y 5 estrellas');
    }

    // Verificar que la receta existe
    const recipe = await this.prisma.recipe.findUnique({
      where: { id: recipeId },
    });

    if (!recipe) {
      throw new NotFoundException('Receta no encontrada');
    }

    // Crear o actualizar rating
    const rating = await this.prisma.rating.upsert({
      where: {
        user_id_recipe_id: {
          user_id: userId,
          recipe_id: recipeId,
        },
      },
      update: { 
        score,
        ...(comment !== undefined && { comment }),
      },
      create: {
        user_id: userId,
        recipe_id: recipeId,
        score,
        ...(comment && { comment }),
      },
      include: {
        user: {
          select: {
            id: true,
            name: true,
            username: true,
          },
        },
      },
    });

    // Recalcular promedio (según HU8: calcular con agregación)
    await this.updateRecipeAverageRating(recipeId);

    return rating;
  }

  // HU8: Recalcular promedio de rating de una receta
  private async updateRecipeAverageRating(recipeId: string) {
    const ratings = await this.prisma.rating.findMany({
      where: { recipe_id: recipeId },
      select: { score: true },
    });

    const averageRating = ratings.length > 0 
      ? ratings.reduce((sum, r) => sum + r.score, 0) / ratings.length 
      : 0;

    await this.prisma.recipe.update({
      where: { id: recipeId },
      data: {
        average_rating: averageRating,
        rating_count: ratings.length,
      },
    });

    return averageRating;
  }

  // Obtener ratings de una receta
  async getRecipeRatings(recipeId: string) {
    const ratings = await this.prisma.rating.findMany({
      where: { recipe_id: recipeId },
      include: {
        user: {
          select: {
            id: true,
            name: true,
            username: true,
            profile_picture_url: true,
          },
        },
      },
      orderBy: { created_at: 'desc' },
    });

    return ratings;
  }

  // Obtener rating del usuario para una receta
  async getUserRating(userId: string, recipeId: string) {
    const rating = await this.prisma.rating.findUnique({
      where: {
        user_id_recipe_id: {
          user_id: userId,
          recipe_id: recipeId,
        },
      },
    });

    return rating || null;
  }
}