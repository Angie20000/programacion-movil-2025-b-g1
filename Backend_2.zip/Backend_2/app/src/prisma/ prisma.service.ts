import { Injectable, OnModuleInit } from '@nestjs/common';
import { PrismaClient } from '@prisma/client';


@Injectable()
export class PrismaService extends PrismaClient implements OnModuleInit {
  async onModuleInit() {
    await super.$connect();
    console.log('✅ Prisma conectado correctamente a PostgreSQL');
  }
}