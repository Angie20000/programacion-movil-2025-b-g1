import { Injectable, ConflictException, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/ prisma.service';
import * as bcrypt from 'bcrypt';

@Injectable()
export class UsersService {
  constructor(private prisma: PrismaService) {}

  async createUser(data: { email: string; password: string; name?: string; username?: string }) {
    const existing = await this.prisma.user.findUnique({ where: { email: data.email } });
    if (existing) throw new ConflictException('El email ya está registrado');

    const hashedPassword = await bcrypt.hash(data.password, 10);

    return this.prisma.user.create({
      data: {
        email: data.email,
        password: hashedPassword,
        name: data.name,
        username: data.username,
      },
    });
  }

  async findByEmail(email: string) {
    const user = await this.prisma.user.findUnique({ where: { email } });
    if (!user) throw new NotFoundException('Usuario no encontrado');
    return user;
  }

  async findById(id: string) {
    const user = await this.prisma.user.findUnique({ 
      where: { id },
      select: {
        id: true,
        email: true,
        name: true,
        username: true,
        profile_picture_url: true,
        bio: true,
        created_at: true,
        updated_at: true
      }
    });
    
    if (!user) throw new NotFoundException('Usuario no encontrado');
    return user;
  }

  async findAll() {
    return this.prisma.user.findMany({
      select: { 
        id: true, 
        name: true, 
        email: true, 
        username: true, 
        created_at: true, 
        updated_at: true 
      },
    });
  }
}