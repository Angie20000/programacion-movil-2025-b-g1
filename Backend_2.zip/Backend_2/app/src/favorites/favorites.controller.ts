import { Controller, Get, Post, Delete, Body, Param, UseGuards } from '@nestjs/common';
import { FavoritesService } from './favorites.service';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { CurrentUser } from '../users/current-user.decorator';

@Controller('favorites')
export class FavoritesController {
  constructor(private readonly favoritesService: FavoritesService) {}

  // HU7: Marcar como favorito
  @UseGuards(JwtAuthGuard)
  @Post()
  async addFavorite(
    @CurrentUser() user: any,
    @Body() body: { recipeId: string },
  ) {
    return this.favoritesService.addFavorite(user.user_id, body.recipeId);
  }

  // HU7: Eliminar de favoritos
  @UseGuards(JwtAuthGuard)
  @Delete(':recipeId')
  async removeFavorite(
    @CurrentUser() user: any,
    @Param('recipeId') recipeId: string,
  ) {
    return this.favoritesService.removeFavorite(user.user_id, recipeId);
  }

  // HU7: Listar favoritos del usuario
  @UseGuards(JwtAuthGuard)
  @Get()
  async getUserFavorites(@CurrentUser() user: any) {
    return this.favoritesService.getUserFavorites(user.user_id);
  }

  // Verificar si una receta es favorita
  @UseGuards(JwtAuthGuard)
  @Get(':recipeId/check')
  async checkFavorite(
    @CurrentUser() user: any,
    @Param('recipeId') recipeId: string,
  ) {
    return this.favoritesService.isFavorite(user.user_id, recipeId);
  }
}