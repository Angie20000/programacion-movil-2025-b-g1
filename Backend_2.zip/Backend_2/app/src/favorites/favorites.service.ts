import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/ prisma.service';

@Injectable()
export class FavoritesService {
  constructor(private prisma: PrismaService) {}

  // HU7: Marcar como favorito
  async addFavorite(userId: string, recipeId: string) {
    // Verificar que la receta existe
    const recipe = await this.prisma.recipe.findUnique({
      where: { id: recipeId },
    });

    if (!recipe) {
      throw new NotFoundException('Receta no encontrada');
    }

    return this.prisma.favorite.upsert({
      where: {
        user_id_recipe_id: {
          user_id: userId,
          recipe_id: recipeId,
        },
      },
      update: {}, // Si ya existe, no hacer nada
      create: {
        user_id: userId,
        recipe_id: recipeId,
      },
      include: {
        recipe: {
          include: {
            author: {
              select: {
                id: true,
                name: true,
                username: true,
              },
            },
          },
        },
      },
    });
  }

  // HU7: Eliminar de favoritos
  async removeFavorite(userId: string, recipeId: string) {
    try {
      await this.prisma.favorite.delete({
        where: {
          user_id_recipe_id: {
            user_id: userId,
            recipe_id: recipeId,
          },
        },
      });
      return { message: 'Receta eliminada de favoritos' };
    } catch (error) {
      throw new NotFoundException('Receta no encontrada en favoritos');
    }
  }

  // HU7: Listar favoritos de usuario
  async getUserFavorites(userId: string) {
    const favorites = await this.prisma.favorite.findMany({
      where: { user_id: userId },
      include: {
        recipe: {
          include: {
            author: {
              select: {
                id: true,
                name: true,
                username: true,
              },
            },
            ratings: {
              select: {
                score: true,
              },
            },
          },
        },
      },
      orderBy: { created_at: 'desc' },
    });

    // Calcular promedio de rating para cada receta favorita
    return favorites.map(fav => ({
      ...fav,
      recipe: {
        ...fav.recipe,
        average_rating: fav.recipe.ratings.length > 0 
          ? fav.recipe.ratings.reduce((sum, r) => sum + r.score, 0) / fav.recipe.ratings.length 
          : 0,
      },
    }));
  }

  // Verificar si una receta es favorita del usuario
  async isFavorite(userId: string, recipeId: string) {
    const favorite = await this.prisma.favorite.findUnique({
      where: {
        user_id_recipe_id: {
          user_id: userId,
          recipe_id: recipeId,
        },
      },
    });

    return { isFavorite: !!favorite };
  }
}